# Build status — ScreenshotService

## Current recording backend

- Recording prefers the selected adapter's native hardware API (NVIDIA NVENC, AMD AMF, or modern Intel oneVPL) when enabled and supported; Media Foundation hardware MFT remains the fallback. The experimental FFmpeg/D3D12VA recording backend and its settings/capability paths have been removed.
- Encoder availability is determined by a hardware-MFT probe which creates, writes, and finalizes an MP4 using the same Media Foundation configuration used by recording. The cache key is `ScreenshotService-probe-v29 MFT-only` and invalidates old D3D12-era capability results.
- The MFT encoder selector and Auto ranking use only profiles that passed the probe. Exact hardware URL, CLSID, candidate ordinal, and vendor pinning remain in place. If native encoding fails before the first compressed packet, the failed attempt is removed and the same request is retried through the hardware MFT. If MFT setup fails with both GPU-texture and CPU-fed input paths, recording stops with an explicit error; there is no software-video encoder fallback.
- HDR desktop capture and conversion remain on the D3D11 shader path. The HDR screenshot copy bug is also fixed: row copies use `img->bpp` (8 bytes per pixel for half-float HDR, 4 for SDR).
- The build does not compile the experimental `d3d12encode.c` backend or link `d3d12.lib`. The native vendor encoders use D3D11 textures; FFmpeg is optional for the smoke-test script and not required for video recording.

## AMD AMF follow-up

- The capture-adapter diagnostic uses only fields present in `DXGI_ADAPTER_DESC` (`Description`, `VendorId`, `DeviceId`). Adapter flags are not part of that structure; this avoids an MSVC C2039 build failure.

- H.264 B-picture configuration now sets `AMF_VIDEO_ENCODER_MAX_NUM_REFRAMES` before `AMF_VIDEO_ENCODER_B_PIC_PATTERN`; otherwise runtimes can advertise B-frame support yet reject the configuration when the reference-frame limit remains at its default.
- AMF initialization gets additional conservative retries (no lookahead, no B-frames, no VBAQ, simpler preset) before falling back to the hardware Media Foundation transform. HEVC Main10/HDR is not silently downgraded by this retry ladder.
- The log now includes the DXGI capture adapter description and PCI vendor/device IDs, so a selected Media Foundation vendor cannot be mistaken for the native encoder actually picked from the capture adapter.

## Validation

- Source inspection and reference scans were run after removing the experimental D3D12VA backend and adding native vendor API paths.
- This environment cannot compile the Windows application with the target Windows SDK or run the user's GPU driver. A native MSVC build and runtime validation of MFT recording, HDR, audio, and final MP4 output are still required.

## Monitor selection and accent theme update

- Full-monitor recording asks which display to use when multiple displays are connected; a single display is selected implicitly. If Force-last has a saved stable target that disappeared, the picker reopens even if only one other monitor remains.
- Settings > Hotkeys includes a mode selector: ask when multiple displays are connected (default), or force the last selected physical display. In force mode, if the stored display target is no longer connected, the picker reappears and stores the replacement selection; an inline hint explains this. DisplayConfig target paths are used for stable identity; the GDI device name is retained for diagnostics only and is never treated as a stable physical identity.
- The monitor picker uses a custom theme-painted header (avoids low-contrast native tool-window title text), an explicit close button, a two-line monitor layout, and DPI-scaled dimensions. Height is calculated in client coordinates, so the final monitor row is not clipped by a native caption frame.
- Monitor rows retain the Windows accent on their outlines, with a thin idle stroke and stronger hover/focus states; a numbered accent chip separates the shortcut from monitor name, GDI device and resolution.
- Toolbar active-selection buttons and the selection rectangle/freeform outline use the Windows accent colour rather than a hard-coded blue.
- Runtime validation requires a Windows build and testing with monitor hot-plug; this environment cannot run the native Windows UI.


## Native encoder and recording reliability work

- Added the native vendor encoders from the compatible GPL source tree: NVIDIA NVENC, AMD AMF, and Intel oneVPL. The D3D12VA/FFmpeg recording backend remains removed; native APIs use D3D11 textures, and Media Foundation remains the hardware-MFT fallback.
- Native configurations retry without lookahead and then without B-frames if the vendor runtime refuses those settings. If startup/encoding/flush fails before the first compressed packet, the empty attempt is removed and the same recording options are retried through the hardware MFT. Failures after emitted packets preserve the partial for diagnosis.
- Added crash/first-chance diagnostics, a watchdog/minidump for a stalled recording, Windows Application Error/Hang event lookup after a native encoder crash, and one-start disablement of that native encoder after a recorded crash. Diagnostic writes used by crash handling bypass the opt-in debug-log switch.
- Added localized hover tooltips for the snip toolbar and recording stop button.
- Added `--record-smoke-test [seconds]` and `tests/record-smoke-test.ps1`. The test captures a short silent MP4 on the primary monitor and validates MP4 structure, not just the filename or file size.
- Intel oneVPL currently targets the modern API 2.x runtime for Arc/Xe class GPUs. No separate legacy Media SDK/QSV implementation is included; older Intel HD systems continue to use a compatible hardware MFT when offered by Windows.

## Validation limits

- Static validation and packaging are run in this environment. The Windows application cannot be compiled against the target Windows SDK or exercised against NVIDIA/AMD/Intel drivers here. The smoke test must be run on Windows hardware before treating native encoder support as runtime-verified.

## Registry-backed settings migration

- The application reads/writes configuration under `HKLM\Software\Gallery Inc\ScreenshotSvc`; the encoder capability cache is in its `EncoderCache` subkey. The old per-user `settings.ini` is imported once only and is no longer written.
- Run `setup-registry-settings.bat` as Administrator once to create the machine-wide key and grant normal users read/write/create-subkey access. ScreenshotService remains `asInvoker`; it does not need to run as administrator.
- Native Windows build/runtime validation is still required; this environment cannot execute the MSVC build or test the registry ACL on Windows.
